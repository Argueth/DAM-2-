/**
 * 
 */
/**
 * 
 */
module Assessable_Activity {
	requires java.xml;
}